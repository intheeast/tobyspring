package com.intheeast.springframe.domain;

public class UserLevel {
	
	public static final int BASIC = 1; // constant : 끊임없는, 변경할 수 없다.
	public static final int SILVER = 2; // constant : 끊임없는, 변경할 수 없다.
	public static final int GOLD = 3; // constant : 끊임없는, 변경할 수 없다.

}
