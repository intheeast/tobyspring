package com.intheeast.sandbox;

public class Singleton {
	// private???
	private Singleton() {}
}
