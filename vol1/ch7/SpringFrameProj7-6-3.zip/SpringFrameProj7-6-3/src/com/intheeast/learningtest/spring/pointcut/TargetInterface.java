package com.intheeast.learningtest.spring.pointcut;

public interface TargetInterface {
	void hello();
	void hello(String a);
	int plus(int a, int b);
	int minus(int a, int b);
}
