package com.intheeast;

import org.springframework.core.io.Resource;

public interface SqlMapConfig {
	Resource getSqlMapResouce();
}
