package com.intheeast.learningtest.spring.web;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;

import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.servlet.DispatcherServlet;

public class Program {

	public static void main(String[] args) {
		ContextLoaderListener cll;
		DispatcherServlet ds;
		ServletContext sc;
		ServletConfig scf;

	}

}
