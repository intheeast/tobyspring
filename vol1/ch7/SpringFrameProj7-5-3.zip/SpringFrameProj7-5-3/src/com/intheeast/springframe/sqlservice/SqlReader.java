package com.intheeast.springframe.sqlservice;

public interface SqlReader {
	void read(SqlRegistry sqlRegistry);
}
