package com.intheeast.learningtest.spring.pointcut;

public class Bean {
	public void method() throws RuntimeException {
	}
}
