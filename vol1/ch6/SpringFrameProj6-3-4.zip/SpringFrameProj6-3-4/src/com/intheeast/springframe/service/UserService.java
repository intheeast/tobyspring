package com.intheeast.springframe.service;

import com.intheeast.springframe.domain.User;

public interface UserService {
	void add(User user);
	void upgradeLevels();
}

