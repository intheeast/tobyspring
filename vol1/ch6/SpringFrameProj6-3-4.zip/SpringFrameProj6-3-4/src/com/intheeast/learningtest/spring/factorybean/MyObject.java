package com.intheeast.learningtest.spring.factorybean;

public class MyObject {
	
	

}
