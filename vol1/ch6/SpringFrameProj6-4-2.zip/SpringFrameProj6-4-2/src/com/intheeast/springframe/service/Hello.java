package com.intheeast.springframe.service;

public interface Hello {
	
	String sayHello(String name);
	String sayHi(String name);
	String sayThanks(String name);

}
